// countNumbers.c
// To count the number of integers in the range [limit1, limit2]
// which are not divisible by divisor1 and divisor2
#include <stdio.h>

int count_numbers(int, int, int, int);

int main(void) {    
	int divisor1, divisor2, limit1, limit2;

	printf("Enter 2 divisors: ");

	printf("Enter lower and upper limits: ");

	printf("Answer = %d\n");

	return 0;
}


