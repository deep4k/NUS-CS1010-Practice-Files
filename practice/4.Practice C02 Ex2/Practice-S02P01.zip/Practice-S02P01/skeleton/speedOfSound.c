// speedOfSound.c
// Read a temperature and compute the speed of sound in air.
// You must write a function speed_of_sound().
#include <stdio.h>

int main(void) {
    float degree;  

    printf("Temperature in degree Fahrenheit: ");
    scanf("%f", &degree);


    return 0;
}

