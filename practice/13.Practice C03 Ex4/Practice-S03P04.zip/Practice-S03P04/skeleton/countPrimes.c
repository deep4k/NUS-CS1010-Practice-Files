// countPrimes.c
// To count the number of primes in the range [1, limit]
// where limit is entered by user.
#include <stdio.h>

int is_prime(int);

int main(void) {    
	int limit;

	printf("Enter limit: ");
	scanf("%d", &limit);


	return 0;
}

