// perfectNumber.c 
// Repeatedly reads a non-negative value, and stops when zero is read.
// For each positive value read, it checks if the value is a perfect number.

#include <stdio.h>

int is_perfect(int);

int main(void) {
	int num;

	printf("Enter number: ");
	scanf("%d", &num);


	return 0;
}

