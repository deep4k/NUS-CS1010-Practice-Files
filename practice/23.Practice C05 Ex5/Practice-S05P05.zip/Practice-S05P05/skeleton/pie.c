#include <stdio.h>
#define MAX_SLICES 20

int maxCherries(int [], int);

int main(){
	printf("Enter number of slices: ");
	
	printf("Enter numbers of cherries: ");

	printf("The maximum number of cherries Alice can get is .\n"); // Incomplete

	return 0;
}
