// validate.c
// To read age from user, until the 
// age entered is valid (1 - 100).
#include <stdio.h>

int main(void) {    

	printf("Enter age: ");

	printf("Your age is %d.\n");
	printf("Number of attempts = %d\n");

	return 0;
}

