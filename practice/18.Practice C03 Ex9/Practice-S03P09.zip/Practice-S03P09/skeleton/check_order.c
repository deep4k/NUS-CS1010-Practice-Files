// check_order.c 
// Repeatedly reads positive integer, until the input value 
// is zero, or the data are not in increasing order.

#include <stdio.h>

int main(void) {

	printf("Enter positive integer: ");

	return 0;
}

