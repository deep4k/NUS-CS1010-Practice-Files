// magicNumber.c
// You must write a function get_magic().
#include <stdio.h>

int main(void) {

    printf("Enter 1st value: ");

    printf("Enter 2nd value: ");


    return 0;
}

